# সংরক্ষণ ও পরে হোস্টিংয়ে নেওয়ার নির্দেশনা

এই প্রজেক্ট টোটো কোম্পানির হোটেল পার্টনার বুকিং প্ল্যাটফর্মের কনসেপ্ট ডেমো। মালিক প্রবীর দত্ত; নিজস্ব হোটেল লিও ইন্টারন্যাশনাল, গ্যাংটক। শুরুতে ডোমেন ও হোস্টিং কেনা হয়নি। পরে মালিক www.hocab.in এবং নিজের হোস্টিংয়ে WordPress থাকার কথা জানিয়েছেন; এই পরিবেশ থেকে live hosting যাচাই বা login করা যায়নি।

## সংরক্ষিত জিনিস

- `index.html`: সম্পূর্ণ ডেমোর কোড, ডিজাইন ও ব্রাউজারভিত্তিক কার্যক্রম।
- `README.md`: চালুর নিয়ম, বুকিং/হিসাবের নিয়ম, যাচাই ও সীমাবদ্ধতা।
- স্ক্রিনশট: এজেন্ট, হোটেল কর্তৃপক্ষ, অ্যাডমিন, বুকিং, রিপোর্ট ও ভাউচার।
- `toto-partner-demo.zip`: অন্য কম্পিউটারে রাখার ও খোলার প্যাকেজ।
- রিপোজিটরির Git commit এবং আলাদা Git bundle: কোডের ইতিহাসসহ স্থানীয় ব্যাকআপ।

এই ফাইলগুলিতে বাস্তব অতিথির তথ্য বা গোপন credential রাখা হয়নি। নিজের কম্পিউটারে ZIP ও Git bundle ডাউনলোড করে রাখুন। শুধু এই workspace বা কথোপকথনের ওপর স্থায়ী সংরক্ষণের জন্য নির্ভর করবেন না। Cloud environment snapshot রাখতে environment settings-এ সংরক্ষিত নির্দেশনা review/save করে publish করতে হবে।

## বুকিংয়ের মূল নিয়ম

এজেন্ট অতিথি, ফোন, তারিখ, রুম, প্রাপ্তবয়স্ক/শিশু, শিশু পলিসি ও খাবারের তথ্য দিয়ে অনুরোধ করেন। জমা দেওয়া অনুরোধ পেন্ডিং থাকে; শুধু সংশ্লিষ্ট হোটেলের অনুমোদনে নিশ্চিত হয়। নিশ্চিত বুকিং বাতিলের অনুরোধ হোটেল অনুমোদন না করা পর্যন্ত রুম ধরে রাখে। কোম্পানি অ্যাডমিন পুরো নেটওয়ার্ক দেখেন।

## শুধু ডেমো অনলাইনে দেখাতে

ডোমেন ও static hosting পাওয়ার পরে `index.html` হোস্টিংয়ের প্রকাশযোগ্য root-এ রাখলে ডেমো দেখানো যাবে। ডোমেনের DNS, HTTPS এবং হোস্টিংয়ের upload/deployment পদ্ধতি প্রদানকারীর নিয়ম অনুযায়ী সেট করতে হবে। অনুমোদিত hosting access থাকলে পরে সেই নির্দিষ্ট প্ল্যাটফর্মের জন্য deployment করা যাবে। এখন কোনো public site বা DNS পরিবর্তন করা হয়নি।

স্ক্রিনশট ও ZIP প্রকাশ করা বাধ্যতামূলক নয়। বাস্তব ব্যক্তিগত তথ্যসহ browser storage ব্যবহার করবেন না। ডেমোর তথ্য localStorage-এ থাকে; ডোমেন বদলালে বা অন্য ডিভাইসে গেলে একই তথ্য স্বয়ংক্রিয়ভাবে দেখা যায় না।

## বাস্তব ব্যবসার সফটওয়্যার চালু করতে

ডোমেন/হোস্টিং কিনলেই এই ডেমো production CRM হয়ে যাবে না। আগে shared database, নিরাপদ login/permissions, transactional inventory, actual hotel content/rates/taxes/commission/cancellation policies, payments/refunds, notifications, backup এবং deployment monitoring তৈরি ও যাচাই করতে হবে। `README.md`-এ সেই কাজগুলোর তালিকা আছে।

পরে কাজ শুরু করার জন্য এই প্রজেক্ট/ZIP এবং এই নির্দেশনা ব্যবহার করুন। হোস্টিংয়ের নাম, ডোমেন এবং যথাযথ access জানা হলে পরবর্তী deployment ধাপ নির্ধারণ করা যাবে। গোপন password বা API key চ্যাটে লিখবেন না; তখন সমর্থিত নিরাপদ credential পদ্ধতি ব্যবহার করতে হবে।

## WordPress সংস্করণ (৬ অক্টোবর ২০২৬)

`../wordpress/toto-partner-booking.zip` নতুন shared-database booking plugin। এটি আগের preview wrapper থেকে আলাদা। Login, assigned hotel/agent access, room/inventory, pending/approval/cancellation, server quotes ও manual ledger যুক্ত হয়েছে। বিস্তারিত `../wordpress/toto-partner-booking/README-BN.md`-এ। WordPress ও MariaDB test installation-এ পরীক্ষা হয়েছে; hocab.in-এ upload এখনও হয়নি।
